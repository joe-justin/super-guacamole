#!/bin/bash
#################################################################
# Team: HARPOCRATES						#
# Name: secure_os.sh						#
# Date: 2-Feb-2022						#
# Desc: Simple program to secure common known vulnerabilities	#
#	in Ubuntu 18.04 server					#
# Ref:	Binary Defence, Portsentry, Fail2Ban, rkhunter,		#
#	Jshielder, Ubuntu community forums, Unhide etc.		#
#################################################################


#Common functions used across.

progress_bar ()
{
    bar="#########################################################"
    barlength=${#bar}
    i=0
    while ((i < 100)); do
        n=$((i*barlength / 100))
        printf "\e[00;34m\r[%-${barlength}s]\e[00m" "${bar:0:n}"
        ((i += RANDOM%5+2))
        sleep 0.02
    done
}



function cmpltd() {
    echo " "
    echo -e "Done."
}

# Check if running with root User

check_root() {
if [ "$USER" != "root" ]; then
      echo "Permission Denied"
      echo "Can only be run by root"
      exit
elif [[ $# -eq 0  ||  -z "$1" ]]; then
	echo "Please pass the user to set required permission"
	exit
else
      home=$(pwd)
      username="$1"
      #usermod -a -G root "$1"
      echo $username
fi
}


# Setting a more restrictive UMASK
restrictive_umask(){
   
   
   echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
   echo -e "\e[93m[+]\e[00m Setting UMASK to a more Restrictive Value (027)"
   echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
   echo ""
   progress_bar
   cp ./login.defs /etc/login.defs
   echo ""
   echo "OK"
   cmpltd
}

#Disabling Unused Filesystems

unused_filesystems(){
   
   
   echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
   echo -e "\e[93m[+]\e[00m Disabling Unused FileSystems"
   echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
   echo ""
   progress_bar
   echo "install cramfs /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install freevxfs /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install jffs2 /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install hfs /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install hfsplus /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install squashfs /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install udf /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install vfat /bin/true" >> /etc/modprobe.d/CIS.conf
   echo " OK"
   cmpltd
}


uncommon_netprotocols(){
   
   
   echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
   echo -e "\e[93m[+]\e[00m Disabling Uncommon Network Protocols"
   echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
   echo ""
   progress_bar
   echo "install dccp /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install sctp /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install rds /bin/true" >> /etc/modprobe.d/CIS.conf
   echo "install tipc /bin/true" >> /etc/modprobe.d/CIS.conf
   echo " OK"
   cmpltd

}


#Securing /tmp Folder
secure_tmp(){
  
  
  echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
  echo -e "\e[93m[+]\e[00m Securing /tmp Folder"
  echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
  echo ""
  echo "We will create a FileSystem for the /tmp Directory and set Proper Permissions "
  progress_bar
  dd if=/dev/zero of=/usr/tmpDISK bs=1024 count=2048000
  mkdir /tmpbackup
  cp -Rpf /tmp /tmpbackup
  mount -t tmpfs -o loop,noexec,nosuid,rw /usr/tmpDISK /tmp
  chmod 1777 /tmp
  cp -Rpf /tmpbackup/* /tmp/
  rm -rf /tmpbackup
  echo "/usr/tmpDISK  /tmp    tmpfs   loop,nosuid,nodev,noexec,rw  0 0" >> /etc/fstab
  sudo mount -o remount /tmp
  cmpltd
}


# Secure SSH
secure_ssh(){
    
    
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Securing SSH"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    echo -n " Securing SSH..."
    progress_bar
    sed s/USERNAME/$username/g ./sshd_config > /etc/ssh/sshd_config; echo "OK"
    chattr -i /home/$username/.ssh/authorized_keys
    service ssh restart
    cmpltd
}


# Set IPTABLES Rules
set_iptables(){
    
    
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Setting IPTABLE RULES"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    echo -n " Setting Iptables Rules..."
    progress_bar
    sh ./iptables.sh
    cp ./iptables.sh /etc/init.d/
    chmod +x /etc/init.d/iptables.sh
    ln -s /etc/init.d/iptables.sh /etc/rc2.d/S99iptables.sh
    cmpltd
}


# Tune and Secure Kernel
tune_secure_kernel(){
    
    
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Tuning and Securing the Linux Kernel"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    echo " Securing Linux Kernel"
    progress_bar
    echo "* hard core 0" >> /etc/security/limits.conf
    cp ./sysctl.conf /etc/sysctl.conf; echo " OK"
    cp ./ufw /etc/default/ufw
    sysctl -e -p
    cmpltd
}


# Additional Hardening Steps
additional_hardening(){
    
    
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Running additional Hardening Steps"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    echo "Running Additional Hardening Steps...."
    progress_bar
    echo tty1 > /etc/securetty
    chmod 0600 /etc/securetty
    chmod 700 /root
    chmod 600 /boot/grub/grub.cfg
    #Remove AT to restrict Cron
    apt purge at
    echo ""
    echo " Securing Cron "
    progress_bar
    touch /etc/cron.allow
    chmod 600 /etc/cron.allow
    awk -F: '{print $1}' /etc/passwd | grep -v root > /etc/cron.deny
    echo ""
    echo ""
    echo "Disabling USB Support"
    progress_bar
    echo "blacklist usb-storage" | sudo tee -a /etc/modprobe.d/blacklist.conf
    update-initramfs -u
    echo "OK"
    cmpltd
}


# Disable Compilers for all but root
disable_compilers(){
    
    
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Disabling Compilers"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    echo "Disabling Compilers....."
    progress_bar
    chmod 750 /usr/bin/as >/dev/null 2>&1
    chmod 750 /usr/bin/byacc >/dev/null 2>&1
    chmod 750 /usr/bin/yacc >/dev/null 2>&1
    chmod 750 /usr/bin/bcc >/dev/null 2>&1
    chmod 750 /usr/bin/kgcc >/dev/null 2>&1
    chmod 750 /usr/bin/cc >/dev/null 2>&1
    chmod 750 /usr/bin/gcc >/dev/null 2>&1
    chmod 750 /usr/bin/*c++ >/dev/null 2>&1
    chmod 750 /usr/bin/*g++ >/dev/null 2>&1
    progress_bar
    echo " OK"
    cmpltd
}


file_permissions(){
 
  
  echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
  echo -e "\e[93m[+]\e[00m Setting File Permissions on Critical System Files"
  echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
  echo ""
  progress_bar
  sleep 2
  chmod -R g-wx,o-rwx /var/log/*

  chown root:root /etc/ssh/sshd_config
  chmod og-rwx /etc/ssh/sshd_config

  chown root:root /etc/passwd
  chmod 644 /etc/passwd

  chown root:shadow /etc/shadow
  chmod o-rwx,g-wx /etc/shadow

  chown root:root /etc/group
  chmod 644 /etc/group

  chown root:shadow /etc/gshadow
  chmod o-rwx,g-rw /etc/gshadow

  chown root:root /etc/passwd-
  chmod 600 /etc/passwd-

  chown root:root /etc/shadow-
  chmod 600 /etc/shadow-

  chown root:root /etc/group-
  chmod 600 /etc/group-

  chown root:root /etc/gshadow-
  chmod 600 /etc/gshadow-


  echo -e ""
  echo -e "Setting Sticky bit on all world-writable directories"
  sleep 2
  progress_bar

  df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d -perm -0002 2>/dev/null | xargs chmod a+t

  echo " OK"
  cmpltd

}


# Install Unhide
install_unhide(){


    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Installing UnHide"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    sleep 1
    apt -y install unhide
    echo ""
    echo " man unhide "
    cmpltd
}

# Install and Configure Artillery
install_artillery (){


    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Cloning Repo and Installing Artillery"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    git clone https://github.com/BinaryDefense/artillery
    cd artillery/
    python setup.py
    cd ..
    echo ""
    echo "Setting Iptable rules for artillery"
    progress_bar
    for port in 22 1433 8080 21 5900 53 110 1723 1337 10000 5800 44443 16993; do
      echo "iptables -A INPUT -p tcp -m tcp --dport $port -j ACCEPT" >> /etc/init.d/iptables.sh
    done
    echo ""
    echo "Artillery configuration file is /var/artillery/config"
    cmpltd
}


# Install RootKit Hunter
install_rootkit_hunter(){


    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Installing RootKit Hunter"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    sleep 1
    git clone https://git.code.sf.net/p/rkhunter/rkh_code rkhunter-1.4.6a
    cd rkhunter-1.4.6a/
    sh installer.sh --layout /usr --install
    cd ..
    rkhunter --update
    rkhunter --propupd
    echo ""
    echo " ***To Run RootKit Hunter ***"
    echo "     rkhunter -c --enable all --disable none"
    echo "     Detailed report on /var/log/rkhunter.log"
    cmpltd
}

install_fail2ban(){


    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Installing Fail2Ban"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    apt install sendmail
    apt install fail2ban
    #cp /etc/fail2ban/jail.local /etc/fail2ban/jail.conf
    /etc/init.d/fail2ban restart
    cmpltd
}

install_artillery (){


    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo -e "\e[93m[+]\e[00m Cloning Repo and Installing Artillery"
    echo -e "\e[34m---------------------------------------------------------------------------------------------------------\e[00m"
    echo ""
    git clone https://github.com/BinaryDefense/artillery artillery
    cd artillery/
    python setup.py
    cd ..
    echo ""
    echo "Setting Iptable rules for artillery"
    progress_bar
    for port in 22 1433 8080 21 5900 53 110 1723 1337 10000 5800 44443 16993; do
      echo "iptables -A INPUT -p tcp -m tcp --dport $port -j ACCEPT" >> /etc/init.d/iptables.sh
    done
    echo ""
    echo "Artillery configuration file is /var/artillery/config"
    cmpltd
}




#Main to call actions in sequence

check_root "$1"

restrictive_umask

unused_filesystems

uncommon_netprotocols

secure_tmp

secure_ssh

set_iptables

tune_secure_kernel

additional_hardening

disable_compilers

file_permissions

install_unhide

install_rootkit_hunter

install_fail2ban

install_artillery

# Merge insall & configure tools like rkhunter, fail2ban, unhide etc. pending. Completed and testing in local in progress.
